package com.example.demo.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Course;
import com.example.demo.repository.CourseRepository;

import java.util.List;
import java.util.Optional;


@Service
public class CourseService {

    private final CourseRepository courseRepository;

    @Autowired
    public CourseService(CourseRepository courseRepository) {
        this.courseRepository = courseRepository;
    }

    public List<Course> getAllCourses() {
        return courseRepository.findAll();
    }

    public Optional<Course> getCourseById(Long id) {
        return courseRepository.findById(id);
    }

    public Course saveCourse(Course course) {
        return courseRepository.save(course);
    }
    
    public Course addCourse(Course course) {
        // Implement the logic to add a new course here
        return courseRepository.save(course);
    }

    public void deleteCourse(Long id) {
        courseRepository.deleteById(id);
    }

    // Additional CRUD operations

    public Course updateCourse(Long id, Course updatedCourse) {
        Optional<Course> optionalCourse = courseRepository.findById(id);
        if (optionalCourse.isPresent()) {
            Course existingCourse = optionalCourse.get();
            existingCourse.setName(updatedCourse.getName());
            existingCourse.setCode(updatedCourse.getCode());
            existingCourse.setDescription(updatedCourse.getDescription());
            // Update other properties as needed
            return courseRepository.save(existingCourse);
        } else {
            // Handle not found scenario
            throw new RuntimeException("Course not found with id: " + id);
        }
    }

    // Add more methods for specific business logic related to courses
}

