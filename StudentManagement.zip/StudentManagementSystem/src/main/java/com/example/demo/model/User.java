package com.example.demo.model;


import jakarta.persistence.*;


@Entity
@Table(name = "users")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(nullable = false)
    private String username;

    @Column(nullable = false)
    private String password;

    @Column(nullable = false)
    private String firstName;

    @Column(nullable = false)
    private String lastName;

    @Column(nullable = false, unique = true)
    private String email;

    // Constructors, getters, and setters

    public User() {
    }

    // Constructor for admin registration
    public User(String username, String password, String firstName, String lastName, String email) {
        this.username = username;
        this.password = password;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
    }

    // Constructor for student registration
    public User(String firstName, String lastName, String email) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        generateUsername();
        generatePassword();
    }

    // Getters and setters
    // Implement them as needed

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    // Generate username based on first name and last name
    public void generateUsername() {
        // Logic to generate username
        // For example: concatenate first name and last name
        this.username = firstName.toLowerCase() + lastName.toLowerCase();
    }

    // Generate password based on first name and last name
    public void generatePassword() {
        // Logic to generate password
        // For example: concatenate first name, last name, and a random number
        this.password = firstName.substring(0, Math.min(firstName.length(), 4)).toLowerCase() +
                lastName.substring(0, Math.min(lastName.length(), 4)).toLowerCase() +
                (int) (Math.random() * 1000);
    }
}
