package com.example.demo.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.model.Enrollment;
import com.example.demo.model.Grade;

@Repository
public interface GradeRepository extends JpaRepository<Grade, Long> {

    Grade findByEnrollment(Enrollment enrollment);
}
