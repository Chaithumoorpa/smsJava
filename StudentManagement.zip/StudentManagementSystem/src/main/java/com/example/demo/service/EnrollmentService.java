package com.example.demo.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Enrollment;
import com.example.demo.repository.EnrollmentRepository;

import java.util.List;
import java.util.Optional;

@Service
public class EnrollmentService {

    private final EnrollmentRepository enrollmentRepository;

    @Autowired
    public EnrollmentService(EnrollmentRepository enrollmentRepository) {
        this.enrollmentRepository = enrollmentRepository;
    }

    public List<Enrollment> getAllEnrollments() {
        return enrollmentRepository.findAll();
    }

    public Optional<Enrollment> getEnrollmentById(Long id) {
        return enrollmentRepository.findById(id);
    }

    public Enrollment addEnrollment(Enrollment enrollment) {
        return enrollmentRepository.save(enrollment);
    }

    public void deleteEnrollment(Long id) {
        enrollmentRepository.deleteById(id);
    }

    // Other methods as needed
    
   

    public Enrollment updateEnrollment(Long id, Enrollment updatedEnrollment) {
        // Retrieve the existing enrollment by ID
        Optional<Enrollment> optionalEnrollment = enrollmentRepository.findById(id);
        
        // Check if the enrollment exists
        if (optionalEnrollment.isPresent()) {
            Enrollment existingEnrollment = optionalEnrollment.get();
            
            // Update the existing enrollment with the new data
            // Assuming Enrollment has appropriate setters for its fields
            existingEnrollment.setStudent(updatedEnrollment.getStudent());
            existingEnrollment.setCourse(updatedEnrollment.getCourse());
            existingEnrollment.setGrade(updatedEnrollment.getGrade());

            // Save the updated enrollment
            return enrollmentRepository.save(existingEnrollment);
        } else {
            // Enrollment with the given ID not found, handle appropriately
            // For example, throw an exception or return null
            return null;
        }
    }
    
}

