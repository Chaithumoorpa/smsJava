package com.example.demo.model;



import jakarta.persistence.*;


@Entity
public class Grade {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @OneToOne
    private Enrollment enrollment;
    
    private double value;
    
    // Constructors, getters, and setters
    
    public Grade() {
        // Default constructor
    }

    public Grade(Enrollment enrollment, double value) {
        this.enrollment = enrollment;
        this.value = value;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Enrollment getEnrollment() {
        return enrollment;
    }

    public void setEnrollment(Enrollment enrollment) {
        this.enrollment = enrollment;
    }

    public double getValue() {
        return value;
    }

    public void setValue(double value) {
        this.value = value;
    }
    
    // Other methods
    
    @Override
    public String toString() {
        return "Grade [id=" + id + ", enrollment=" + enrollment + ", value=" + value + "]";
    }

    // Add other methods as needed
}

