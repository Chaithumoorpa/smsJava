package com.example.demo.service;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Enrollment;
import com.example.demo.model.Grade;
import com.example.demo.repository.GradeRepository;

@Service
public class GradeService {

    @Autowired
    private GradeRepository gradeRepository;

    public List<Grade> getAllGrades() {
        return gradeRepository.findAll();
    }

    public Grade getGradeById(Long id) {
        Optional<Grade> optionalGrade = gradeRepository.findById(id);
        return optionalGrade.orElse(null);
    }

    public Grade addGrade(Grade grade) {
        return gradeRepository.save(grade);
    }

    public Grade updateGrade(Long id, Grade newGrade) {
        Optional<Grade> optionalGrade = gradeRepository.findById(id);
        if (optionalGrade.isPresent()) {
            Grade grade = optionalGrade.get();
            grade.setValue(newGrade.getValue());
            return gradeRepository.save(grade);
        }
        return null;
    }

    public boolean deleteGrade(Long id) {
        Optional<Grade> optionalGrade = gradeRepository.findById(id);
        if (optionalGrade.isPresent()) {
            gradeRepository.deleteById(id);
            return true;
        }
        return false;
    }

    public Grade getByEnrollment(Enrollment enrollment) {
        return gradeRepository.findByEnrollment(enrollment);
    }
}

