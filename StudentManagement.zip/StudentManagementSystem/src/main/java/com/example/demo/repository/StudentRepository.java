package com.example.demo.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.model.Student;

import java.util.List;
import java.util.UUID;

@Repository
public interface StudentRepository extends JpaRepository<Student, UUID> {
    // You can add custom methods for specific queries if needed
    List<Student> findByFirstName(String firstName);

    List<Student> findByLastName(String lastName);

    Student findByUsername(String username);
}

