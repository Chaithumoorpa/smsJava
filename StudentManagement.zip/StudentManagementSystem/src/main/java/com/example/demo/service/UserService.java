package com.example.demo.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.User;
import com.example.demo.repository.UserRepository;

import java.util.Optional;
import java.util.UUID;

@Service
public class UserService {

    private final UserRepository userRepository;

    @Autowired
    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public User createUser(User user) {
        return userRepository.save(user);
    }

    public User getUser(Long userId) {
        Optional<User> optionalUser = userRepository.findById(userId);
        return optionalUser.orElse(null);
    }

    public User registerAdmin(User user) {
        // Validate admin registration fields (e.g., username, password, email)
        if (user.getUsername() == null || user.getPassword() == null || user.getEmail() == null) {
            return null;
        }

        // Generate UUID for admin user
        user.setId(UUID.randomUUID().getMostSignificantBits() & Long.MAX_VALUE);
        
        return userRepository.save(user);
    }

    public User registerStudent(User user) {
        // Validate student registration fields (e.g., first name, last name, email)
        if (user.getFirstName() == null || user.getLastName() == null || user.getEmail() == null) {
            return null;
        }

        // Generate username and password for student
        user.generateUsername();
        user.generatePassword();

        return userRepository.save(user);
    }

    public User updateUser(Long userId, User updatedUser) {
        User user = getUser(userId);
        if (user != null) {
            // Update user details
            // Ensure not to update the ID or other crucial fields
            // Example: user.setFirstName(updatedUser.getFirstName());
            return userRepository.save(user);
        }
        return null;
    }

    public boolean deleteUser(Long userId) {
        User user = getUser(userId);
        if (user != null) {
            userRepository.delete(user);
            return true;
        }
        return false;
    }
}

